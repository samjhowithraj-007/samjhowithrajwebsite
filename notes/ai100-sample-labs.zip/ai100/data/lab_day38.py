from pypdf import PdfReader
from bs4 import BeautifulSoup
html = BeautifulSoup(open("handbook.html", encoding="utf-8").read(), "html.parser")
print("html:", html.title.text, "|", len(html.find_all("p")), "paragraphs")
pdf = PdfReader("rules.pdf")
print("pdf pages:", len(pdf.pages))
print(pdf.pages[1].extract_text()[:70].replace("\n", " | "))
text = open("policy.txt", encoding="utf-8").read()
print("txt:", len(text), "characters")