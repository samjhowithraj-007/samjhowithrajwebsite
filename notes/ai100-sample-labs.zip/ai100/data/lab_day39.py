text = open("policy.txt", encoding="utf-8").read()

def fixed(text, size=200, overlap=40):
    step = size - overlap
    return [text[i:i + size] for i in range(0, len(text), step)]

paras = [p.strip() for p in text.split("\n\n") if p.strip()]
fx = fixed(text)
print("fixed chunks:", len(fx), "| paragraph chunks:", len(paras))
print("fixed chunk ends :", repr(fx[0][-30:]))
print("paragraph chunk  :", repr(paras[1][:60]))