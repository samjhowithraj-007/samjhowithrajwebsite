from sentence_transformers import CrossEncoder
from hybrid import hybrid, texts
ce = CrossEncoder("cross-encoder/ms-marco-MiniLM-L-6-v2")
q = "What should I do first when someone gets a burn?"
top = hybrid(q, k=5)
scores = ce.predict([(q, texts[i]) for i in top])
print("hybrid order :", [int(i) for i in top])
best = sorted(zip(scores, top), reverse=True)[:2]
for s, i in best:
    print(round(float(s), 1), texts[i][:66])