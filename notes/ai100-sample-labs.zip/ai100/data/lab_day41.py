import json, re
from bs4 import BeautifulSoup
from pypdf import PdfReader
chunks = []

def add(text, source, where):
    text = re.sub(r"\s+", " ", text).strip()
    if len(text) > 30 and text not in {c["text"] for c in chunks}:
        chunks.append({"id": len(chunks), "text": text, "source": source, "where": where})

soup = BeautifulSoup(open("handbook.html", encoding="utf-8").read(), "html.parser")
for tag in soup(["nav", "footer"]):
    tag.decompose()
section = ""
for el in soup.find_all(["h2", "p"]):
    if el.name == "h2":
        section = el.text.strip()
    else:
        add(el.text, "handbook.html", section)
for n, page in enumerate(PdfReader("rules.pdf").pages, 1):
    body = " ".join(page.extract_text().split("\n")[2:])
    for sentence in re.split(r"(?<=[.!?])\s+(?=[A-Z])", body):
        add(sentence, "rules.pdf", "page %d" % n)
for para in open("policy.txt", encoding="utf-8").read().split("\n\n"):
    add(para, "policy.txt", "paragraph")
json.dump(chunks, open("chunks.json", "w", encoding="utf-8"), indent=1)
by = {}
for c in chunks:
    by[c["source"]] = by.get(c["source"], 0) + 1
print(len(chunks), "chunks saved:", by)
print(chunks[0]["where"], "|", chunks[0]["text"][:60])