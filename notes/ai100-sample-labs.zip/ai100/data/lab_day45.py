import json, re
from rank_bm25 import BM25Okapi
chunks = json.load(open("chunks.json", encoding="utf-8"))
tok = lambda s: re.findall(r"[a-z0-9]+", s.lower())
bm25 = BM25Okapi([tok(c["text"]) for c in chunks])

def keyword_search(q, k=2):
    s = bm25.get_scores(tok(q))
    return [(round(float(s[i]), 1), chunks[i]["text"][:60]) for i in s.argsort()[::-1][:k]]

for q in ["Form EX-7", "How much time off do I get for my wedding?"]:
    print("Q:", q)
    for score, text in keyword_search(q):
        print("  ", score, text)