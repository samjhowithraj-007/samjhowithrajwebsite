import re
from bs4 import BeautifulSoup
soup = BeautifulSoup(open("handbook.html", encoding="utf-8").read(), "html.parser")
for tag in soup(["nav", "footer"]):
    tag.decompose()
rows, section = [], ""
for el in soup.find_all(["h2", "p"]):
    if el.name == "h2":
        section = el.text.strip()
    else:
        text = re.sub(r"\s+", " ", el.text).strip()
        rows.append({"text": text, "source": "handbook.html", "section": section})
print(len(rows), "paragraphs kept (menu and footer removed)")
print(rows[3])