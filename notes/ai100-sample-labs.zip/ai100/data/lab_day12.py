import numpy as np
from sentence_transformers import SentenceTransformer
notes = open("notes.txt", encoding="utf-8").read().splitlines()
model = SentenceTransformer("all-MiniLM-L6-v2")
vecs = model.encode(notes, normalize_embeddings=True)

def search(query, k=3):
    scores = vecs @ model.encode([query], normalize_embeddings=True)[0]
    return [(round(float(scores[i]), 2), notes[i]) for i in np.argsort(-scores)[:k]]

for q in ["how do I undo a mistake in my project?",
          "keeping secrets safe", "repeat something many times"]:
    print("Q:", q)
    for score, note in search(q):
        print("  ", score, note[:44])