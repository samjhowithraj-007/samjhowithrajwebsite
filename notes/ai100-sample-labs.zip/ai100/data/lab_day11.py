import numpy as np
from sentence_transformers import SentenceTransformer
model = SentenceTransformer("all-MiniLM-L6-v2")
sents = ["How do I reset my password?",
         "I forgot my login password",
         "Best places to eat in Pune"]
vecs = model.encode(sents, normalize_embeddings=True)
print(vecs.shape)
print(np.round(vecs @ vecs.T, 2))