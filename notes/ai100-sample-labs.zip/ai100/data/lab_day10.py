import tiktoken
enc = tiktoken.get_encoding("cl100k_base")
text = "Tokens are the pieces a model reads."
ids = enc.encode(text)
print(ids)
print([enc.decode([i]) for i in ids])
for word in ["chai", "unbelievably", "नमस्ते"]:
    print(word, "->", len(enc.encode(word)), "token(s)")