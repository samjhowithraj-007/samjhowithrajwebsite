import json
from sentence_transformers import CrossEncoder
from hybrid import keyword, semantic, hybrid, texts
ce = CrossEncoder("cross-encoder/ms-marco-MiniLM-L-6-v2")

def rerank(q, k=3):
    top = hybrid(q, k=6)
    scores = ce.predict([(q, texts[i]) for i in top])
    return [i for _, i in sorted(zip(scores, top), reverse=True)][:k]

questions = json.load(open("questions.json", encoding="utf-8"))
methods = {"keyword": keyword, "semantic": semantic, "hybrid": hybrid, "hybrid+rerank": rerank}
for name, fn in methods.items():
    hits = sum(any(q["must"] in texts[i] for i in fn(q["q"], k=3)) for q in questions)
    print(f"{name:14} recall@3 = {hits}/{len(questions)}")