import json, re
import numpy as np
from rank_bm25 import BM25Okapi
from sentence_transformers import SentenceTransformer
chunks = json.load(open("chunks.json", encoding="utf-8"))
texts = [c["text"] for c in chunks]
tok = lambda s: re.findall(r"[a-z0-9]+", s.lower())
bm25 = BM25Okapi([tok(t) for t in texts])
model = SentenceTransformer("all-MiniLM-L6-v2")
vecs = model.encode(texts, normalize_embeddings=True)

def ranks(scores):
    r = np.empty(len(scores))
    r[np.argsort(-scores)] = np.arange(1, len(scores) + 1)
    return r

def keyword(q, k=3):
    return list(np.argsort(-bm25.get_scores(tok(q)))[:k])

def semantic(q, k=3):
    return list(np.argsort(-(vecs @ model.encode([q], normalize_embeddings=True)[0]))[:k])

def hybrid(q, k=3, c=60):
    kw = ranks(bm25.get_scores(tok(q)))
    sem = ranks(vecs @ model.encode([q], normalize_embeddings=True)[0])
    return list(np.argsort(-(1 / (c + kw) + 1 / (c + sem)))[:k])

