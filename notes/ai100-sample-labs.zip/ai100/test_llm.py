"""Tests ask() for real against a tiny stand-in server (no key, no vendor). The server only echoes, so the replies prove the wrapper, not a model."""
import os, json, threading, http.server, pathlib, importlib

class Stub(http.server.BaseHTTPRequestHandler):
    def do_POST(self):
        body = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
        text = body["messages"][-1]["content"]
        if self.path.endswith("/messages"):
            out = {"content": [{"type": "text", "text": "anthropic-shape echo: " + text}]}
        else:
            out = {"choices": [{"message": {"role": "assistant", "content": "openai-shape echo: " + text}}]}
        data = json.dumps(out).encode()
        self.send_response(200); self.send_header("Content-Type", "application/json"); self.send_header("Content-Length", str(len(data))); self.end_headers(); self.wfile.write(data)
    def log_message(self, *a): pass

srv = http.server.HTTPServer(("127.0.0.1", 0), Stub)
threading.Thread(target=srv.serve_forever, daemon=True).start()
base = "http://127.0.0.1:%d" % srv.server_address[1]
import llm
msg = [{"role": "user", "content": "Say hi"}]
llm.CFG.update(base_url=base + "/v1", model="stub-model")
os.environ["LLM_MODE"] = "live"; os.environ["LLM_RECORD"] = "1"
print("1 openai shape :", llm.ask(msg, lab="selftest"))
llm.CFG.update(provider="anthropic", base_url=base)
print("2 anthropic    :", llm.ask(msg, lab="selftest"))
llm.CFG.update(provider="openai", base_url=base + "/v1")
os.environ["LLM_MODE"] = "recorded"; srv.shutdown()   # server is gone: only the saved reply can answer
print("3 recorded     :", llm.ask(msg, lab="selftest"))
try:
    llm.ask([{"role": "user", "content": "never saved"}], lab="selftest")
except LookupError as e:
    print("4 not recorded :", e)
pathlib.Path("recorded/selftest.json").unlink()
