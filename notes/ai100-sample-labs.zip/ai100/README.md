# ai100: sample labs for "Build with AI: 100 Days to Job-Ready" (free sample, Chapters 3, 11, 13)

Checked 25 Nov 2026 with Python 3.14. Any Python 3.11 or newer should work.

## Run the labs (no API key needed)
1. Open a terminal in this folder and make a virtual environment:
   python -m venv .venv
   .venv\Scripts\activate          (Windows)   or   source .venv/bin/activate   (Mac, Linux)
2. Install the libraries: pip install -r requirements.txt
   (This is large because it includes PyTorch. The first run of Days 11 and 47 also downloads two small models of about 90 MB each.)
3. Go into the data folder and run a lab: cd data   then   python lab_day10.py
   Run them in order inside a chapter. Day 46 saves hybrid.py, which Days 47 and 48 use. Day 41 saves chunks.json, which Days 45 to 48 use (a copy is included).

## The ask() wrapper (Day 3 of the full book)
llm.py has one function, ask(). config.toml is the only place to choose the model. Modes: live (your own key in an environment variable), recorded (saved replies, no key) or a local model on your own laptop. These sample labs do not call any model. Never put a key in a file or share it.
