"""ai100/llm.py: one thin function, ask(), used by every lab (Day 3)."""
import os, json, hashlib, tomllib, pathlib
import httpx

HERE = pathlib.Path(__file__).parent
CFG = tomllib.loads((HERE / "config.toml").read_text(encoding="utf-8"))


def _key(messages, model):
    raw = json.dumps({"m": messages, "model": model, "p": CFG["provider"]}, sort_keys=True)
    return hashlib.sha256(raw.encode()).hexdigest()[:16]


def ask(messages, lab="scratch", **options):
    """messages = [{"role": "user", "content": "..."}]. Returns the reply text."""
    mode = os.environ.get("LLM_MODE", CFG["mode"])
    store = HERE / "recorded" / (lab + ".json")
    saved = json.loads(store.read_text(encoding="utf-8")) if store.exists() else {}
    key = _key(messages, CFG["model"])
    if mode == "recorded":
        if key not in saved:
            raise LookupError(f"no recorded reply for this prompt in {store.name}; run once with LLM_MODE=live")
        return saved[key]["reply"]
    secret = os.environ.get(CFG["api_key_env"], "")
    if CFG["provider"] == "anthropic":
        url, head = CFG["base_url"].rstrip("/") + "/v1/messages", {"x-api-key": secret, "anthropic-version": "2023-06-01"}
        body = {"model": CFG["model"], "max_tokens": options.get("max_tokens", 500), "messages": messages}
        pick = lambda j: j["content"][0]["text"]
    else:
        url, head = CFG["base_url"].rstrip("/") + "/chat/completions", ({"Authorization": "Bearer " + secret} if secret else {})   # local models need no key
        body = {"model": CFG["model"], "messages": messages, **options}
        pick = lambda j: j["choices"][0]["message"]["content"]
    r = httpx.post(url, headers=head, json=body, timeout=60)
    r.raise_for_status()
    reply = pick(r.json())
    if os.environ.get("LLM_RECORD") == "1":      # save the real reply so learners can run offline
        saved[key] = {"model": CFG["model"], "reply": reply}
        store.parent.mkdir(exist_ok=True)
        store.write_text(json.dumps(saved, indent=1), encoding="utf-8")
    return reply
